-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: CompendiumSystem
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announcements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `content` text NOT NULL,
  `type` enum('deadline','event','important','maintenance','information') NOT NULL DEFAULT 'information',
  `start_date` datetime NOT NULL,
  `end_date` datetime DEFAULT NULL,
  `is_pinned` tinyint(1) NOT NULL DEFAULT 0,
  `status` enum('draft','published','archived') NOT NULL DEFAULT 'draft',
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_type` (`type`),
  KEY `idx_pinned` (`is_pinned`),
  KEY `idx_dates` (`start_date`,`end_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER audit_announcement_creation
            AFTER INSERT ON ANNOUNCEMENTS
            FOR EACH ROW
            BEGIN
                INSERT INTO AUDIT_LOGS (table_name, record_id, action, new_values, user_id, ip_address)
                VALUES ('ANNOUNCEMENTS', NEW.id, 'INSERT', 
                    JSON_OBJECT('title', NEW.title, 'type', NEW.type, 'status', NEW.status, 'is_pinned', NEW.is_pinned),
                    NEW.created_by, @current_user_ip);
            END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER audit_announcement_changes
            AFTER INSERT ON ANNOUNCEMENTS
            FOR EACH ROW
            BEGIN
                INSERT INTO AUDIT_LOGS (table_name, record_id, action, new_values, user_id)
                VALUES ('ANNOUNCEMENTS', NEW.id, 'INSERT', 
                       JSON_OBJECT('title', NEW.title, 'type', NEW.type, 'status', NEW.status),
                       NEW.created_by);
            END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER auto_archive_announcements
            BEFORE UPDATE ON ANNOUNCEMENTS
            FOR EACH ROW
            BEGIN
                IF NEW.end_date IS NOT NULL AND NEW.end_date < NOW() AND NEW.status = 'published' THEN
                    SET NEW.status = 'archived';
                END IF;
            END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER audit_announcement_updates
            AFTER UPDATE ON ANNOUNCEMENTS
            FOR EACH ROW
            BEGIN
                IF OLD.title != NEW.title OR OLD.status != NEW.status OR OLD.is_pinned != NEW.is_pinned OR OLD.type != NEW.type THEN
                    INSERT INTO AUDIT_LOGS (table_name, record_id, action, old_values, new_values, user_id, ip_address)
                    VALUES ('ANNOUNCEMENTS', NEW.id, 'UPDATE', 
                        JSON_OBJECT('title', OLD.title, 'status', OLD.status, 'is_pinned', OLD.is_pinned, 'type', OLD.type),
                        JSON_OBJECT('title', NEW.title, 'status', NEW.status, 'is_pinned', NEW.is_pinned, 'type', NEW.type),
                        @current_user_id, @current_user_ip);
                END IF;
            END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER audit_announcement_deletions
            BEFORE DELETE ON ANNOUNCEMENTS
            FOR EACH ROW
            BEGIN
                INSERT INTO AUDIT_LOGS (table_name, record_id, action, old_values, user_id, ip_address)
                VALUES ('ANNOUNCEMENTS', OLD.id, 'DELETE', 
                    JSON_OBJECT('title', OLD.title, 'type', OLD.type, 'created_by', OLD.created_by),
                    @current_user_id, @current_user_ip);
            END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `table_name` varchar(50) NOT NULL,
  `record_id` int(11) NOT NULL,
  `action` enum('INSERT','UPDATE','DELETE') NOT NULL,
  `old_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_values`)),
  `new_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_values`)),
  `user_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `changed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_table_record` (`table_name`,`record_id`),
  KEY `idx_action` (`action`),
  KEY `idx_changed_at` (`changed_at`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,'USER_INFORMATION',3,'UPDATE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\", \"Email\": \"a@usep.edu.ph\"}','{\"User_Role\": \"student\", \"Acc_Status\": \"approved\", \"Email\": \"a@usep.edu.ph\"}',0,NULL,'2025-11-15 04:29:55'),(2,'USER_INFORMATION',5,'DELETE','{\"User_Role\": \"faculty\", \"Acc_Status\": \"pending\", \"Email\": \"w@usep.edu.ph\", \"First_Name\": \"w\", \"Last_Name\": \"w\"}',NULL,NULL,NULL,'2025-11-15 05:24:56'),(3,'USER_INFORMATION',3,'DELETE','{\"User_Role\": \"student\", \"Acc_Status\": \"approved\", \"Email\": \"a@usep.edu.ph\", \"First_Name\": \"a\", \"Last_Name\": \"a\"}',NULL,NULL,NULL,'2025-11-15 05:24:58'),(4,'USER_INFORMATION',6,'UPDATE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\", \"Email\": \"a@usep.edu.ph\"}','{\"User_Role\": \"student\", \"Acc_Status\": \"approved\", \"Email\": \"a@usep.edu.ph\"}',0,NULL,'2025-11-15 05:29:19'),(5,'USER_INFORMATION',4,'UPDATE','{\"User_Role\": \"faculty\", \"Acc_Status\": \"approved\", \"Email\": \"apjandog00362@usep.edu.ph\"}','{\"User_Role\": \"SubAdmin\", \"Acc_Status\": \"approved\", \"Email\": \"apjandog00362@usep.edu.ph\"}',0,NULL,'2025-11-15 05:32:41'),(6,'USER_INFORMATION',7,'DELETE','{\"User_Role\": \"faculty\", \"Acc_Status\": \"pending\", \"Email\": \"w@usep.edu.ph\", \"First_Name\": \"w\", \"Last_Name\": \"w\"}',NULL,NULL,NULL,'2025-11-15 05:56:46'),(7,'USER_INFORMATION',8,'DELETE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\", \"Email\": \"q@usep.edu.ph\", \"First_Name\": \"q\", \"Last_Name\": \"q\"}',NULL,NULL,NULL,'2025-11-15 05:57:01'),(8,'USER_INFORMATION',6,'DELETE','{\"User_Role\": \"student\", \"Acc_Status\": \"approved\", \"Email\": \"a@usep.edu.ph\", \"First_Name\": \"a\", \"Last_Name\": \"a\"}',NULL,NULL,NULL,'2025-11-15 05:57:02'),(9,'USER_INFORMATION',9,'DELETE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\", \"Email\": \"a@usep.edu.ph\", \"First_Name\": \"a\", \"Last_Name\": \"a\"}',NULL,NULL,NULL,'2025-11-15 06:09:48'),(10,'USER_INFORMATION',10,'UPDATE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\", \"Email\": \"a@usep.edu.ph\"}','{\"User_Role\": \"student\", \"Acc_Status\": \"approved\", \"Email\": \"a@usep.edu.ph\"}',0,NULL,'2025-11-15 06:10:48'),(11,'USER_INFORMATION',11,'DELETE','{\"User_Role\": \"\", \"Acc_Status\": \"approved\", \"Email\": \"pltirador00205@usep.edu.ph\", \"First_Name\": \"PAULEENE\", \"Last_Name\": \"TIRADOR\"}',NULL,NULL,NULL,'2025-11-15 06:13:11'),(12,'USER_INFORMATION',12,'DELETE','{\"User_Role\": \"\", \"Acc_Status\": \"approved\", \"Email\": \"pltirador00205@usep.edu.ph\", \"First_Name\": \"PAULEENE\", \"Last_Name\": \"TIRADOR\"}',NULL,NULL,NULL,'2025-11-15 08:23:08'),(13,'USER_INFORMATION',13,'DELETE','{\"User_Role\": \"\", \"Acc_Status\": \"approved\", \"Email\": \"pltirador00205@usep.edu.ph\", \"First_Name\": \"PAULEENE\", \"Last_Name\": \"TIRADOR\"}',NULL,NULL,NULL,'2025-11-15 08:26:21'),(14,'USER_INFORMATION',14,'DELETE','{\"User_Role\": \"faculty\", \"Acc_Status\": \"approved\", \"Email\": \"pltirador00205@usep.edu.ph\", \"First_Name\": \"PAULEENE\", \"Last_Name\": \"TIRADOR\"}',NULL,NULL,NULL,'2025-11-15 08:26:54'),(15,'USER_INFORMATION',15,'DELETE','{\"User_Role\": \"\", \"Acc_Status\": \"approved\", \"Email\": \"pltirador00205@usep.edu.ph\", \"First_Name\": \"PAULEENE\", \"Last_Name\": \"TIRADOR\"}',NULL,NULL,NULL,'2025-11-15 08:29:55'),(16,'USER_INFORMATION',17,'DELETE','{\"User_Role\": \"\", \"Acc_Status\": \"approved\", \"Email\": \"pltirador00205@usep.edu.ph\", \"First_Name\": \"PAULEENE\", \"Last_Name\": \"TIRADOR\"}',NULL,NULL,NULL,'2025-11-15 08:41:23'),(17,'USER_INFORMATION',18,'DELETE','{\"User_Role\": \"\", \"Acc_Status\": \"approved\", \"Email\": \"pltirador00205@usep.edu.ph\", \"First_Name\": \"PAULEENE\", \"Last_Name\": \"TIRADOR\"}',NULL,NULL,NULL,'2025-11-15 08:51:10'),(18,'USER_INFORMATION',19,'DELETE','{\"User_Role\": \"\", \"Acc_Status\": \"approved\", \"Email\": \"pltirador00205@usep.edu.ph\", \"First_Name\": \"PAULEENE\", \"Last_Name\": \"TIRADOR\"}',NULL,NULL,NULL,'2025-11-15 08:56:23'),(19,'USER_INFORMATION',20,'DELETE','{\"User_Role\": \"\", \"Acc_Status\": \"approved\", \"Email\": \"pltirador00205@usep.edu.ph\", \"First_Name\": \"PAULEENE\", \"Last_Name\": \"TIRADOR\"}',NULL,NULL,NULL,'2025-11-15 09:05:57'),(20,'USER_INFORMATION',21,'DELETE','{\"User_Role\": \"student\", \"Acc_Status\": \"approved\", \"Email\": \"pltirador00205@usep.edu.ph\", \"First_Name\": \"PAULEENE\", \"Last_Name\": \"TIRADOR\"}',NULL,NULL,NULL,'2025-11-15 09:13:55'),(21,'USER_INFORMATION',23,'DELETE','{\"User_Role\": \"student\", \"Acc_Status\": \"approved\", \"Email\": \"pltirador00205@usep.edu.ph\", \"First_Name\": \"PAULEENE\", \"Last_Name\": \"TIRADOR\"}',NULL,NULL,NULL,'2025-11-15 09:51:39'),(22,'USER_INFORMATION',25,'DELETE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\", \"Email\": \"123@usep.edu.ph\", \"First_Name\": \"taeTaeTae\", \"Last_Name\": \"qQWER\"}',NULL,NULL,NULL,'2025-11-15 10:09:06'),(23,'USER_INFORMATION',16,'DELETE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\", \"Email\": \"q@usep.edu.ph\", \"First_Name\": \"q\", \"Last_Name\": \"q\"}',NULL,NULL,NULL,'2025-11-15 10:09:08'),(24,'USER_INFORMATION',26,'DELETE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\", \"Email\": \"s@usep.edu.ph\", \"First_Name\": \"juan\", \"Last_Name\": \"delacruz\"}',NULL,NULL,NULL,'2025-11-15 10:09:11'),(25,'USER_INFORMATION',27,'DELETE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\", \"Email\": \"s@usep.edu.ph\", \"First_Name\": \"juan\", \"Last_Name\": \"dela cruz\"}',NULL,NULL,NULL,'2025-11-15 10:23:48'),(26,'USER_INFORMATION',28,'DELETE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\", \"Email\": \"s@usep.edu.ph\", \"First_Name\": \"Juan Tae\", \"Last_Name\": \"Dela Cruz\"}',NULL,NULL,NULL,'2025-11-15 11:18:38');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_attempts`
--

DROP TABLE IF EXISTS `login_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `attempt_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `ip_address` varchar(45) DEFAULT NULL,
  `success` tinyint(1) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_email` (`email`),
  KEY `idx_ip` (`ip_address`),
  KEY `idx_time` (`attempt_time`),
  KEY `idx_success` (`success`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_attempts`
--

LOCK TABLES `login_attempts` WRITE;
/*!40000 ALTER TABLE `login_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type` enum('user_approval','thesis_upload','announcement','system','security') NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `related_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_type` (`type`),
  KEY `idx_read` (`is_read`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (1,3,'user_approval','Account Approved','Your account has been approved. You can now access all features.',0,3,'2025-11-15 04:29:55'),(2,6,'user_approval','Account Approved','Your account has been approved. You can now access all features.',0,6,'2025-11-15 05:29:19'),(3,10,'user_approval','Account Approved','Your account has been approved. You can now access all features.',0,10,'2025-11-15 06:10:48');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `token` varchar(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_used` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_token` (`token`),
  KEY `idx_expires` (`expires_at`),
  KEY `idx_used` (`is_used`),
  KEY `idx_created` (`created_at`),
  CONSTRAINT `password_reset_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_information` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `Role_ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `User_ID` int(11) unsigned NOT NULL,
  `Sub_Admin` enum('Yes','No') NOT NULL,
  `Can_Edit` enum('Yes','No') NOT NULL,
  `Manage_Access` enum('Yes','No') NOT NULL,
  `Original_User_Role` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`Role_ID`),
  KEY `User_ID` (`User_ID`),
  CONSTRAINT `roles_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `user_information` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,2,'No','No','No','student'),(3,4,'Yes','No','No','faculty'),(9,10,'No','No','No','student'),(21,22,'No','No','No','student'),(23,24,'No','No','No','student');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `thesis`
--

DROP TABLE IF EXISTS `thesis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `thesis` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `User_ID` int(11) unsigned NOT NULL,
  `Thesis_Department` varchar(255) NOT NULL,
  `Thesis_Course` varchar(255) NOT NULL,
  `Thesis_Email` varchar(255) NOT NULL,
  `Title` varchar(255) NOT NULL,
  `Author` varchar(255) NOT NULL,
  `Adviser` varchar(255) NOT NULL,
  `HardBound_Available` enum('Yes','No') NOT NULL,
  `Thesis_AbstractFile` longblob NOT NULL,
  `Thesis_File` longblob NOT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`),
  KEY `User_ID` (`User_ID`),
  KEY `Title` (`Title`),
  CONSTRAINT `thesis_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `user_information` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `thesis`
--

LOCK TABLES `thesis` WRITE;
/*!40000 ALTER TABLE `thesis` DISABLE KEYS */;
/*!40000 ALTER TABLE `thesis` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER audit_thesis_uploads
            AFTER INSERT ON THESIS
            FOR EACH ROW
            BEGIN
                INSERT INTO AUDIT_LOGS (table_name, record_id, action, new_values, user_id)
                VALUES ('THESIS', NEW.ID, 'INSERT', 
                       JSON_OBJECT('Title', NEW.Title, 'Author', NEW.Author, 'Thesis_Department', NEW.Thesis_Department),
                       NEW.User_ID);
                
                INSERT INTO NOTIFICATIONS (user_id, type, title, message, related_id)
                SELECT ID, 'thesis_upload', 'New Thesis Uploaded', 
                       CONCAT('A new thesis "', NEW.Title, '" has been uploaded by ', NEW.Author),
                       NEW.ID
                FROM USER_INFORMATION 
                WHERE User_Role IN ('admin', 'superAdmin') AND Acc_Status = 'approved';
            END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER audit_thesis_updates
            AFTER UPDATE ON THESIS
            FOR EACH ROW
            BEGIN
                IF OLD.Title != NEW.Title OR OLD.Author != NEW.Author THEN
                    INSERT INTO AUDIT_LOGS (table_name, record_id, action, old_values, new_values, user_id)
                    VALUES ('THESIS', NEW.ID, 'UPDATE', 
                           JSON_OBJECT('Title', OLD.Title, 'Author', OLD.Author),
                           JSON_OBJECT('Title', NEW.Title, 'Author', NEW.Author),
                           @current_user_id);
                END IF;
            END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER audit_thesis_deletions
            BEFORE DELETE ON THESIS
            FOR EACH ROW
            BEGIN
                INSERT INTO AUDIT_LOGS (table_name, record_id, action, old_values, user_id)
                VALUES ('THESIS', OLD.ID, 'DELETE', 
                       JSON_OBJECT('Title', OLD.Title, 'Author', OLD.Author, 'User_ID', OLD.User_ID),
                       @current_user_id);
            END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `thesis_reviews`
--

DROP TABLE IF EXISTS `thesis_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `thesis_reviews` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `thesis_id` int(11) unsigned NOT NULL,
  `reviewer_id` int(11) unsigned NOT NULL,
  `rating` int(1) NOT NULL CHECK (`rating` between 1 and 5),
  `comments` text DEFAULT NULL,
  `reviewed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID`),
  UNIQUE KEY `unique_review` (`thesis_id`,`reviewer_id`),
  KEY `reviewer_id` (`reviewer_id`),
  CONSTRAINT `thesis_reviews_ibfk_1` FOREIGN KEY (`thesis_id`) REFERENCES `thesis` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `thesis_reviews_ibfk_2` FOREIGN KEY (`reviewer_id`) REFERENCES `user_information` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `thesis_reviews`
--

LOCK TABLES `thesis_reviews` WRITE;
/*!40000 ALTER TABLE `thesis_reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `thesis_reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_information`
--

DROP TABLE IF EXISTS `user_information`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_information` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pswrd` varchar(255) NOT NULL,
  `Salt` varchar(255) NOT NULL,
  `First_Name` varchar(50) NOT NULL,
  `Middle_Name` varchar(50) DEFAULT NULL,
  `Last_Name` varchar(50) NOT NULL,
  `Extension` varchar(20) DEFAULT NULL,
  `Email` varchar(255) NOT NULL,
  `User_ID` varchar(255) NOT NULL,
  `Student_ID` varchar(255) DEFAULT NULL,
  `Employee_ID` varchar(255) DEFAULT NULL,
  `User_Role` enum('student','faculty','SubAdmin','superAdmin') NOT NULL,
  `Acc_Status` enum('pending','approved','rejected') DEFAULT 'pending',
  `Department` varchar(255) NOT NULL,
  `Course` varchar(255) NOT NULL,
  `Profile_Pic` blob DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Email` (`Email`),
  UNIQUE KEY `User_ID` (`User_ID`),
  UNIQUE KEY `Student_ID` (`Student_ID`),
  UNIQUE KEY `Employee_ID` (`Employee_ID`),
  KEY `Email_2` (`Email`),
  KEY `User_ID_2` (`User_ID`),
  KEY `Student_ID_2` (`Student_ID`),
  KEY `Employee_ID_2` (`Employee_ID`),
  KEY `User_Role` (`User_Role`),
  KEY `Acc_Status` (`Acc_Status`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_information`
--

LOCK TABLES `user_information` WRITE;
/*!40000 ALTER TABLE `user_information` DISABLE KEYS */;
INSERT INTO `user_information` VALUES (1,'$2y$10$KFnoRAxQfjnlCMiJkCPBEeKoqhXpe0aX0F6j7f1Da1wfmZTyoEZQK','2d7ed1c6f140a0ae17bf848f175e7526','Super','Admin','Admin',NULL,'admin@usep.edu.ph','ADMIN001',NULL,NULL,'superAdmin','approved','Administration','Administration',NULL,'2025-11-15 04:27:12','2025-11-15 04:27:12'),(2,'$2y$10$nib0g9iU5ftzbow2vLcDHOZ45i039LkOtbUIZOudRopSUW8kXH9Du','5b4b54233fd6b5df0def9c2eedfc6cf0','RONNIE LAURENCE',NULL,'TIEMPO',NULL,'rttiempo00206@usep.edu.ph','STU-43815','STU-43815',NULL,'student','approved','','Not Specified','GIF89a\0\0�\0\0\0\0����!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-15 04:27:43','2025-11-15 04:27:43'),(4,'$2y$10$SknOI.iF2PmECFS0WvNVKu9xTRIfKxx5aoxD4/P92C9bH1joW9s5O','e8e660c76d95b975aad23587d381c022','ANDREA',NULL,'JANDOG',NULL,'apjandog00362@usep.edu.ph','FAC-82309',NULL,'FAC-82309','SubAdmin','approved','Not Specified','','GIF89a\0\0�\0\0\0\0����!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-15 04:33:17','2025-11-15 05:32:41'),(10,'$2y$10$9027ds6eeoCDlS172.Wg1.MnqKyMtahLS7q5rtyxfKyhGl7Q95hra','da08dedef64f3b415405492ce384ce81','a','a','a',NULL,'a@usep.edu.ph','STU20251944',NULL,NULL,'student','approved','','Bachelor of Early Childhood Education','GIF89a\0\0�\0\0\0\0\0���!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-15 06:10:04','2025-11-15 06:10:48'),(22,'$2y$10$2ad1rLcfAXrWaMzYNRtWuurwNwu5VTvd17dXx4kCP/4Ujnp3AQ2XW','75e907e94f507987b10a3c0544e0c490','r','r','r',NULL,'r@usep.edu.ph','STU2025-7914',NULL,NULL,'student','pending','','Bachelor of Secondary Education','GIF89a\0\0�\0\0\0\0\0���!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-15 09:11:47','2025-11-15 09:11:47'),(24,'$2y$10$S.lpt4BfF2pRPcDAHmU1kOkzKnxCkLLXUjUndPVXUV7rG67NqBTyW','9060a0a1ff68d1115446dc412a5347cc','Pauleene',NULL,'Tirador',NULL,'pltirador00205@usep.edu.ph','STU2025-4502',NULL,NULL,'student','approved','','Not Specified','GIF89a\0\0�\0\0\0\0����!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-15 09:59:46','2025-11-15 09:59:46');
/*!40000 ALTER TABLE `user_information` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER audit_user_changes
            AFTER UPDATE ON USER_INFORMATION
            FOR EACH ROW
            BEGIN
                DECLARE changes JSON DEFAULT JSON_OBJECT();
                
                IF OLD.User_Role != NEW.User_Role THEN
                    SET changes = JSON_SET(changes, '$.role_changed', JSON_OBJECT('old', OLD.User_Role, 'new', NEW.User_Role));
                END IF;
                
                IF OLD.Acc_Status != NEW.Acc_Status THEN
                    SET changes = JSON_SET(changes, '$.status_changed', JSON_OBJECT('old', OLD.Acc_Status, 'new', NEW.Acc_Status));
                END IF;
                
                IF OLD.Email != NEW.Email THEN
                    SET changes = JSON_SET(changes, '$.email_changed', JSON_OBJECT('old', OLD.Email, 'new', NEW.Email));
                END IF;
                
                IF JSON_LENGTH(changes) > 0 THEN
                    INSERT INTO AUDIT_LOGS (table_name, record_id, action, old_values, new_values, user_id)
                    VALUES ('USER_INFORMATION', NEW.ID, 'UPDATE', 
                           JSON_OBJECT('User_Role', OLD.User_Role, 'Acc_Status', OLD.Acc_Status, 'Email', OLD.Email),
                           JSON_OBJECT('User_Role', NEW.User_Role, 'Acc_Status', NEW.Acc_Status, 'Email', NEW.Email),
                           @current_user_id);
                END IF;
            END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER notify_user_approval
            AFTER UPDATE ON USER_INFORMATION
            FOR EACH ROW
            BEGIN
                IF OLD.Acc_Status = 'pending' AND NEW.Acc_Status = 'approved' THEN
                    INSERT INTO NOTIFICATIONS (user_id, type, title, message, related_id)
                    VALUES (NEW.ID, 'user_approval', 'Account Approved', 
                           'Your account has been approved. You can now access all features.', NEW.ID);
                END IF;
            END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER audit_user_deletions
            BEFORE DELETE ON USER_INFORMATION
            FOR EACH ROW
            BEGIN
                INSERT INTO AUDIT_LOGS (table_name, record_id, action, old_values, user_id)
                VALUES ('USER_INFORMATION', OLD.ID, 'DELETE', 
                       JSON_OBJECT('User_Role', OLD.User_Role, 'Acc_Status', OLD.Acc_Status, 'Email', OLD.Email, 'First_Name', OLD.First_Name, 'Last_Name', OLD.Last_Name),
                       @current_user_id);
            END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER prevent_last_admin_deletion
            BEFORE DELETE ON USER_INFORMATION
            FOR EACH ROW
            BEGIN
                DECLARE admin_count INT;
                IF OLD.User_Role IN ('admin', 'superAdmin') AND OLD.Acc_Status = 'approved' THEN
                    SELECT COUNT(*) INTO admin_count 
                    FROM USER_INFORMATION 
                    WHERE User_Role IN ('admin', 'superAdmin') AND Acc_Status = 'approved' AND ID != OLD.ID;
                    
                    IF admin_count = 0 THEN
                        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cannot delete the last admin account';
                    END IF;
                END IF;
            END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-16 15:14:05
