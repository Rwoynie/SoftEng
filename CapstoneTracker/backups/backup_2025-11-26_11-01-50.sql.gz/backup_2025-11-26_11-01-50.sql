-- PHP MySQL Backup
-- Generated: 2025-11-26 11:01:50
-- Database: CompendiumSystem

SET FOREIGN_KEY_CHECKS=0;

--
-- Table structure for table `announcements`
--
DROP TABLE IF EXISTS `announcements`;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('deadline','event','important','maintenance','information') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'information',
  `start_date` datetime NOT NULL,
  `end_date` datetime DEFAULT NULL,
  `is_pinned` tinyint(1) NOT NULL DEFAULT '0',
  `status` enum('draft','published','archived') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `created_by` int NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_type` (`type`),
  KEY `idx_pinned` (`is_pinned`),
  KEY `idx_dates` (`start_date`,`end_date`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `announcements`
--
INSERT INTO `announcements` VALUES('1','System Update: Compendium Thesis Platform Enhancements','We are pleased to inform all BSIT students that the Compendium Thesis System has been updated with improved search functionality and faster loading time. These enhancements aim to provide a smoother experience when accessing thesis documents. For any system concerns, please contact the development team.','information','2025-11-25 13:57:00','2025-12-02 13:58:00','0','published','1','2025-11-25 13:58:12','0000-00-00 00:00:00');
INSERT INTO `announcements` VALUES('2','Final Submission Deadline for Thesis Documents','All students are reminded that the final deadline for uploading thesis manuscripts to the Compendium Thesis System is December 15, 2025. Late submissions will not be accommodated. Please ensure all files are complete, properly formatted, and verified before uploading.','deadline','2025-11-25 13:58:00','2025-12-15 13:58:00','0','published','1','2025-11-25 13:59:01','0000-00-00 00:00:00');
INSERT INTO `announcements` VALUES('3','Orientation on the Compendium Thesis System','The BSIT Department will conduct a brief orientation on how to use the Compendium Thesis System on November 30, 2025, at 2:00 PM in the ICT Laboratory. The session will cover account access, uploading guidelines, and system features. All thesis groups are encouraged to attend.','event','2025-11-25 13:59:00','2025-11-30 13:59:00','0','published','1','2025-11-25 13:59:34','0000-00-00 00:00:00');
INSERT INTO `announcements` VALUES('4','Mandatory System Account Verification','All registered students must verify their Compendium Thesis System accounts no later than December 5, 2025. Unverified accounts may experience restricted access to key features such as uploading and document retrieval. Please check your email for the verification link.','important','2025-11-25 13:59:00','2025-12-05 14:00:00','0','published','1','2025-11-25 14:00:17','0000-00-00 00:00:00');

--
-- Table structure for table `audit_logs`
--
DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `table_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `record_id` int NOT NULL,
  `action` enum('INSERT','UPDATE','DELETE') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `old_values` json DEFAULT NULL,
  `new_values` json DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `changed_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_table_record` (`table_name`,`record_id`),
  KEY `idx_action` (`action`),
  KEY `idx_changed_at` (`changed_at`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `audit_logs`
--
INSERT INTO `audit_logs` VALUES('1','USER_INFORMATION','32','UPDATE','{\"User_Role\": \"faculty\", \"Acc_Status\": \"pending\"}','{\"User_Role\": \"faculty\", \"Acc_Status\": \"approved\"}','1','','2025-11-25 13:53:40');
INSERT INTO `audit_logs` VALUES('2','USER_INFORMATION','31','UPDATE','{\"User_Role\": \"faculty\", \"Acc_Status\": \"pending\"}','{\"User_Role\": \"faculty\", \"Acc_Status\": \"approved\"}','1','','2025-11-25 13:53:44');
INSERT INTO `audit_logs` VALUES('3','USER_INFORMATION','30','UPDATE','{\"User_Role\": \"faculty\", \"Acc_Status\": \"pending\"}','{\"User_Role\": \"faculty\", \"Acc_Status\": \"approved\"}','1','','2025-11-25 13:53:56');
INSERT INTO `audit_logs` VALUES('4','USER_INFORMATION','29','UPDATE','{\"User_Role\": \"faculty\", \"Acc_Status\": \"pending\"}','{\"User_Role\": \"faculty\", \"Acc_Status\": \"approved\"}','1','','2025-11-25 13:53:59');
INSERT INTO `audit_logs` VALUES('5','USER_INFORMATION','28','UPDATE','{\"User_Role\": \"faculty\", \"Acc_Status\": \"pending\"}','{\"User_Role\": \"faculty\", \"Acc_Status\": \"approved\"}','1','','2025-11-25 13:54:03');
INSERT INTO `audit_logs` VALUES('6','USER_INFORMATION','27','UPDATE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\"}','{\"User_Role\": \"student\", \"Acc_Status\": \"approved\"}','1','','2025-11-25 13:54:08');
INSERT INTO `audit_logs` VALUES('7','USER_INFORMATION','26','UPDATE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\"}','{\"User_Role\": \"student\", \"Acc_Status\": \"approved\"}','1','','2025-11-25 13:54:11');
INSERT INTO `audit_logs` VALUES('8','USER_INFORMATION','25','UPDATE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\"}','{\"User_Role\": \"student\", \"Acc_Status\": \"approved\"}','1','','2025-11-25 13:54:15');
INSERT INTO `audit_logs` VALUES('9','USER_INFORMATION','14','UPDATE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\"}','{\"User_Role\": \"student\", \"Acc_Status\": \"approved\"}','1','','2025-11-25 13:54:21');
INSERT INTO `audit_logs` VALUES('10','USER_INFORMATION','13','UPDATE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\"}','{\"User_Role\": \"student\", \"Acc_Status\": \"approved\"}','1','','2025-11-25 13:54:26');
INSERT INTO `audit_logs` VALUES('11','USER_INFORMATION','12','UPDATE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\"}','{\"User_Role\": \"student\", \"Acc_Status\": \"approved\"}','1','','2025-11-25 13:54:29');
INSERT INTO `audit_logs` VALUES('12','USER_INFORMATION','11','UPDATE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\"}','{\"User_Role\": \"student\", \"Acc_Status\": \"approved\"}','1','','2025-11-25 13:54:33');
INSERT INTO `audit_logs` VALUES('13','USER_INFORMATION','10','UPDATE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\"}','{\"User_Role\": \"student\", \"Acc_Status\": \"approved\"}','1','','2025-11-25 13:54:37');
INSERT INTO `audit_logs` VALUES('14','USER_INFORMATION','9','UPDATE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\"}','{\"User_Role\": \"student\", \"Acc_Status\": \"approved\"}','1','','2025-11-25 13:54:40');
INSERT INTO `audit_logs` VALUES('15','USER_INFORMATION','8','UPDATE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\"}','{\"User_Role\": \"student\", \"Acc_Status\": \"approved\"}','1','','2025-11-25 13:54:44');
INSERT INTO `audit_logs` VALUES('16','USER_INFORMATION','7','UPDATE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\"}','{\"User_Role\": \"student\", \"Acc_Status\": \"approved\"}','1','','2025-11-25 13:54:48');
INSERT INTO `audit_logs` VALUES('17','USER_INFORMATION','6','UPDATE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\"}','{\"User_Role\": \"student\", \"Acc_Status\": \"approved\"}','1','','2025-11-25 13:54:54');
INSERT INTO `audit_logs` VALUES('18','USER_INFORMATION','5','UPDATE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\"}','{\"User_Role\": \"student\", \"Acc_Status\": \"approved\"}','1','','2025-11-25 13:54:57');
INSERT INTO `audit_logs` VALUES('19','USER_INFORMATION','4','UPDATE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\"}','{\"User_Role\": \"student\", \"Acc_Status\": \"approved\"}','1','','2025-11-25 13:55:01');
INSERT INTO `audit_logs` VALUES('20','USER_INFORMATION','3','UPDATE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\"}','{\"User_Role\": \"student\", \"Acc_Status\": \"approved\"}','1','','2025-11-25 13:55:04');
INSERT INTO `audit_logs` VALUES('21','USER_INFORMATION','2','UPDATE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\"}','{\"User_Role\": \"student\", \"Acc_Status\": \"approved\"}','1','','2025-11-25 13:55:08');
INSERT INTO `audit_logs` VALUES('22','USER_INFORMATION','24','UPDATE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\"}','{\"User_Role\": \"student\", \"Acc_Status\": \"approved\"}','1','','2025-11-25 13:55:23');
INSERT INTO `audit_logs` VALUES('23','USER_INFORMATION','23','UPDATE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\"}','{\"User_Role\": \"student\", \"Acc_Status\": \"approved\"}','1','','2025-11-25 13:55:27');
INSERT INTO `audit_logs` VALUES('24','USER_INFORMATION','22','UPDATE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\"}','{\"User_Role\": \"student\", \"Acc_Status\": \"approved\"}','1','','2025-11-25 13:55:30');
INSERT INTO `audit_logs` VALUES('25','USER_INFORMATION','21','UPDATE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\"}','{\"User_Role\": \"student\", \"Acc_Status\": \"approved\"}','1','','2025-11-25 13:55:34');
INSERT INTO `audit_logs` VALUES('26','USER_INFORMATION','20','UPDATE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\"}','{\"User_Role\": \"student\", \"Acc_Status\": \"approved\"}','1','','2025-11-25 13:55:37');
INSERT INTO `audit_logs` VALUES('27','USER_INFORMATION','17','UPDATE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\"}','{\"User_Role\": \"student\", \"Acc_Status\": \"approved\"}','1','','2025-11-25 13:55:41');
INSERT INTO `audit_logs` VALUES('28','USER_INFORMATION','16','UPDATE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\"}','{\"User_Role\": \"student\", \"Acc_Status\": \"approved\"}','1','','2025-11-25 13:55:44');
INSERT INTO `audit_logs` VALUES('29','USER_INFORMATION','15','UPDATE','{\"User_Role\": \"student\", \"Acc_Status\": \"pending\"}','{\"User_Role\": \"student\", \"Acc_Status\": \"approved\"}','1','','2025-11-25 13:55:48');

--
-- Table structure for table `login_attempts`
--
DROP TABLE IF EXISTS `login_attempts`;
CREATE TABLE `login_attempts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attempt_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `success` tinyint(1) DEFAULT NULL,
  `user_agent` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `idx_email` (`email`),
  KEY `idx_ip` (`ip_address`),
  KEY `idx_time` (`attempt_time`),
  KEY `idx_success` (`success`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `login_attempts`
--

--
-- Table structure for table `notifications`
--
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `type` enum('user_approval','thesis_upload','announcement','system','security') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_read` tinyint(1) DEFAULT '0',
  `related_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_type` (`type`),
  KEY `idx_read` (`is_read`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notifications`
--
INSERT INTO `notifications` VALUES('1','32','user_approval','Account Approved','Your account has been approved. You can now access all features.','0','32','2025-11-25 13:53:40');
INSERT INTO `notifications` VALUES('2','31','user_approval','Account Approved','Your account has been approved. You can now access all features.','0','31','2025-11-25 13:53:44');
INSERT INTO `notifications` VALUES('3','30','user_approval','Account Approved','Your account has been approved. You can now access all features.','0','30','2025-11-25 13:53:56');
INSERT INTO `notifications` VALUES('4','29','user_approval','Account Approved','Your account has been approved. You can now access all features.','0','29','2025-11-25 13:53:59');
INSERT INTO `notifications` VALUES('5','28','user_approval','Account Approved','Your account has been approved. You can now access all features.','0','28','2025-11-25 13:54:03');
INSERT INTO `notifications` VALUES('6','27','user_approval','Account Approved','Your account has been approved. You can now access all features.','0','27','2025-11-25 13:54:08');
INSERT INTO `notifications` VALUES('7','26','user_approval','Account Approved','Your account has been approved. You can now access all features.','0','26','2025-11-25 13:54:11');
INSERT INTO `notifications` VALUES('8','25','user_approval','Account Approved','Your account has been approved. You can now access all features.','0','25','2025-11-25 13:54:15');
INSERT INTO `notifications` VALUES('9','14','user_approval','Account Approved','Your account has been approved. You can now access all features.','0','14','2025-11-25 13:54:21');
INSERT INTO `notifications` VALUES('10','13','user_approval','Account Approved','Your account has been approved. You can now access all features.','0','13','2025-11-25 13:54:26');
INSERT INTO `notifications` VALUES('11','12','user_approval','Account Approved','Your account has been approved. You can now access all features.','0','12','2025-11-25 13:54:29');
INSERT INTO `notifications` VALUES('12','11','user_approval','Account Approved','Your account has been approved. You can now access all features.','0','11','2025-11-25 13:54:33');
INSERT INTO `notifications` VALUES('13','10','user_approval','Account Approved','Your account has been approved. You can now access all features.','0','10','2025-11-25 13:54:37');
INSERT INTO `notifications` VALUES('14','9','user_approval','Account Approved','Your account has been approved. You can now access all features.','0','9','2025-11-25 13:54:40');
INSERT INTO `notifications` VALUES('15','8','user_approval','Account Approved','Your account has been approved. You can now access all features.','0','8','2025-11-25 13:54:44');
INSERT INTO `notifications` VALUES('16','7','user_approval','Account Approved','Your account has been approved. You can now access all features.','0','7','2025-11-25 13:54:48');
INSERT INTO `notifications` VALUES('17','6','user_approval','Account Approved','Your account has been approved. You can now access all features.','0','6','2025-11-25 13:54:54');
INSERT INTO `notifications` VALUES('18','5','user_approval','Account Approved','Your account has been approved. You can now access all features.','0','5','2025-11-25 13:54:57');
INSERT INTO `notifications` VALUES('19','4','user_approval','Account Approved','Your account has been approved. You can now access all features.','0','4','2025-11-25 13:55:01');
INSERT INTO `notifications` VALUES('20','3','user_approval','Account Approved','Your account has been approved. You can now access all features.','0','3','2025-11-25 13:55:04');
INSERT INTO `notifications` VALUES('21','2','user_approval','Account Approved','Your account has been approved. You can now access all features.','0','2','2025-11-25 13:55:08');
INSERT INTO `notifications` VALUES('22','24','user_approval','Account Approved','Your account has been approved. You can now access all features.','0','24','2025-11-25 13:55:23');
INSERT INTO `notifications` VALUES('23','23','user_approval','Account Approved','Your account has been approved. You can now access all features.','0','23','2025-11-25 13:55:27');
INSERT INTO `notifications` VALUES('24','22','user_approval','Account Approved','Your account has been approved. You can now access all features.','0','22','2025-11-25 13:55:30');
INSERT INTO `notifications` VALUES('25','21','user_approval','Account Approved','Your account has been approved. You can now access all features.','0','21','2025-11-25 13:55:34');
INSERT INTO `notifications` VALUES('26','20','user_approval','Account Approved','Your account has been approved. You can now access all features.','0','20','2025-11-25 13:55:37');
INSERT INTO `notifications` VALUES('27','17','user_approval','Account Approved','Your account has been approved. You can now access all features.','0','17','2025-11-25 13:55:41');
INSERT INTO `notifications` VALUES('28','16','user_approval','Account Approved','Your account has been approved. You can now access all features.','0','16','2025-11-25 13:55:44');
INSERT INTO `notifications` VALUES('29','15','user_approval','Account Approved','Your account has been approved. You can now access all features.','0','15','2025-11-25 13:55:48');
INSERT INTO `notifications` VALUES('30','1','thesis_upload','New Thesis Uploaded','A new thesis \"Voting System With Percentage Using PHP/MySQL and ajax\" has been uploaded by Shyrell Mae M. Begonia','0','1','2025-11-25 15:59:38');
INSERT INTO `notifications` VALUES('31','1','thesis_upload','New Thesis Uploaded','A new thesis \"G.L.O.W.E (Generating Light on Wind Energy): An Aid to the Livelihood of Pedicab Drivers\" has been uploaded by Shyrell Mae M. Begonia','0','2','2025-11-25 16:49:47');
INSERT INTO `notifications` VALUES('32','1','thesis_upload','New Thesis Uploaded','A new thesis \"Voting System With Percentage Using PHP/MySQL and ajax\" has been uploaded by Shyrell Mae M. Begonia','0','3','2025-11-25 22:06:03');

--
-- Table structure for table `password_change_pins`
--
DROP TABLE IF EXISTS `password_change_pins`;
CREATE TABLE `password_change_pins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `pin_code` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiry_date` datetime NOT NULL,
  `used` tinyint DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_pin_code` (`pin_code`),
  KEY `idx_expiry_date` (`expiry_date`),
  KEY `idx_used` (`used`),
  CONSTRAINT `password_change_pins_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_information` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_change_pins`
--

--
-- Table structure for table `password_reset_tokens`
--
DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE `password_reset_tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `is_used` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_token` (`token`),
  KEY `idx_expires` (`expires_at`),
  KEY `idx_used` (`is_used`),
  KEY `idx_created` (`created_at`),
  CONSTRAINT `password_reset_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_information` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_reset_tokens`
--

--
-- Table structure for table `roles`
--
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `Role_ID` int unsigned NOT NULL AUTO_INCREMENT,
  `User_ID` int unsigned NOT NULL,
  `Sub_Admin` enum('Yes','No') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Can_Edit` enum('Yes','No') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Manage_Access` enum('Yes','No') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Original_User_Role` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`Role_ID`),
  KEY `User_ID` (`User_ID`),
  CONSTRAINT `roles_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `user_information` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--
INSERT INTO `roles` VALUES('1','2','No','No','No','student');
INSERT INTO `roles` VALUES('2','3','No','No','No','student');
INSERT INTO `roles` VALUES('3','4','No','No','No','student');
INSERT INTO `roles` VALUES('4','5','No','No','No','student');
INSERT INTO `roles` VALUES('5','6','No','No','No','student');
INSERT INTO `roles` VALUES('6','7','No','No','No','student');
INSERT INTO `roles` VALUES('7','8','No','No','No','student');
INSERT INTO `roles` VALUES('8','9','No','No','No','student');
INSERT INTO `roles` VALUES('9','10','No','No','No','student');
INSERT INTO `roles` VALUES('10','11','No','No','No','student');
INSERT INTO `roles` VALUES('11','12','No','No','No','student');
INSERT INTO `roles` VALUES('12','13','No','No','No','student');
INSERT INTO `roles` VALUES('13','14','No','No','No','student');
INSERT INTO `roles` VALUES('14','15','No','No','No','student');
INSERT INTO `roles` VALUES('15','16','No','No','No','student');
INSERT INTO `roles` VALUES('16','17','No','No','No','student');
INSERT INTO `roles` VALUES('17','20','No','No','No','student');
INSERT INTO `roles` VALUES('18','21','No','No','No','student');
INSERT INTO `roles` VALUES('19','22','No','No','No','student');
INSERT INTO `roles` VALUES('20','23','No','No','No','student');
INSERT INTO `roles` VALUES('21','24','No','No','No','student');
INSERT INTO `roles` VALUES('22','25','No','No','No','student');
INSERT INTO `roles` VALUES('23','26','No','No','No','student');
INSERT INTO `roles` VALUES('24','27','No','No','No','student');
INSERT INTO `roles` VALUES('25','28','No','No','No','faculty');
INSERT INTO `roles` VALUES('26','29','No','No','No','faculty');
INSERT INTO `roles` VALUES('27','30','No','No','No','faculty');
INSERT INTO `roles` VALUES('28','31','No','No','No','faculty');
INSERT INTO `roles` VALUES('29','32','No','No','No','faculty');

--
-- Table structure for table `thesis`
--
DROP TABLE IF EXISTS `thesis`;
CREATE TABLE `thesis` (
  `ID` int unsigned NOT NULL AUTO_INCREMENT,
  `User_ID` int unsigned NOT NULL,
  `Thesis_Department` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Thesis_Course` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Thesis_Email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Author` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Adviser` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `HardBound_Available` enum('Yes','No') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Thesis_AbstractFile` longblob NOT NULL,
  `Thesis_File` longblob NOT NULL,
  `uploaded_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  KEY `User_ID` (`User_ID`),
  KEY `Title` (`Title`),
  CONSTRAINT `thesis_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `user_information` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `thesis`
--

--
-- Table structure for table `thesis_reviews`
--
DROP TABLE IF EXISTS `thesis_reviews`;
CREATE TABLE `thesis_reviews` (
  `ID` int unsigned NOT NULL AUTO_INCREMENT,
  `thesis_id` int unsigned NOT NULL,
  `reviewer_id` int unsigned NOT NULL,
  `rating` int NOT NULL,
  `comments` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `reviewed_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `unique_review` (`thesis_id`,`reviewer_id`),
  KEY `reviewer_id` (`reviewer_id`),
  CONSTRAINT `thesis_reviews_ibfk_1` FOREIGN KEY (`thesis_id`) REFERENCES `thesis` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `thesis_reviews_ibfk_2` FOREIGN KEY (`reviewer_id`) REFERENCES `user_information` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `thesis_reviews_chk_1` CHECK ((`rating` between 1 and 5))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `thesis_reviews`
--

--
-- Table structure for table `user_information`
--
DROP TABLE IF EXISTS `user_information`;
CREATE TABLE `user_information` (
  `ID` int unsigned NOT NULL AUTO_INCREMENT,
  `pswrd` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Salt` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `First_Name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Middle_Name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Last_Name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Extension` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `User_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Student_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Employee_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Email_Hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `User_ID_Hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Student_ID_Hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Employee_ID_Hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `User_Role` enum('student','faculty','SubAdmin','superAdmin') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Acc_Status` enum('pending','approved','rejected') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `Department` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Course` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Profile_Pic` longblob,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Email` (`Email`),
  UNIQUE KEY `User_ID` (`User_ID`),
  UNIQUE KEY `Student_ID` (`Student_ID`),
  UNIQUE KEY `Employee_ID` (`Employee_ID`),
  KEY `Email_2` (`Email`),
  KEY `User_ID_2` (`User_ID`),
  KEY `Student_ID_2` (`Student_ID`),
  KEY `Employee_ID_2` (`Employee_ID`),
  KEY `User_Role` (`User_Role`),
  KEY `Acc_Status` (`Acc_Status`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_information`
--
INSERT INTO `user_information` VALUES('1','$2y$10$dIirzCdWTtWKD0WADrNZP.RCqnIgpWKrXUsNrluzhm56upStA0d7W','553254723c7c1cbf4777f75455b86f75','Super','Admin','Admin',NULL,'admin@usep.edu.ph','ADMIN001',NULL,NULL,'5caffe25489200e3c7d32fe159fc4a3493ae08181185ff635ff09d2a3439aac0','89b933c62993dd19e05ae115f18c12491e28b67834079aff0a79c94e4472be1b',NULL,NULL,'superAdmin','approved','Administration','Administration',NULL,'2025-11-25 13:16:16','2025-11-25 13:16:16');
INSERT INTO `user_information` VALUES('2','$2y$10$Aq.wM15EHWJMqlG2yxLFquKQxc7WUU3uTuFT0Wr2fUIw73KLgdmtm','ef9b7eafd5afcf1df15f798f41defc6d','Harold Carl','Y','Carcallas',NULL,'hycarcallas@usep.edu.ph','STU2025-64161',NULL,NULL,'5abfddf0d02a8a12e0b8a821b65e5d63307ae9e922db62ba65db971ac6f51eb1','56052b75f04e70e0d9d82f7f1e3427dfe76afa1990b478fa492d44ff42f595db',NULL,NULL,'student','approved','','Bachelor of Science in Information Technology','GIF89a\0\0�\0\0\0\0\0���!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-25 13:18:56','2025-11-25 13:55:08');
INSERT INTO `user_information` VALUES('3','$2y$10$NzqjrwJED.DlXtnbzADOouhZp7wJ4P46XRWLj8rNYtOCpyg5pUYva','37852a3618f2b282cf6696cdd3747508','Regine Joy Dorothy','L.','Saliot',NULL,'rlsaliot@usep.edu.ph','STU2025-82356',NULL,NULL,'9fbe19261ed7b4be434ff702d3fc090e21377c39f3283e24d3578201202d3c4d','69e32a1f48b6209c02787a77424779140b21d76cca6b10745226037ab20f12ed',NULL,NULL,'student','approved','','Bachelor of Science in Information Technology','GIF89a\0\0�\0\0\0\0\0���!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-25 13:26:19','2025-11-25 13:55:04');
INSERT INTO `user_information` VALUES('4','$2y$10$klZ2gaqzYhXQgk1326opRuFO1w0gZ1W8XqHUROtnEm9076dL4fSEO','b384f318b10271c23d0d8890e3aeb560','Shyrell Mae','M.','Begonia',NULL,'smbegonia@usep.edu.ph','STU2025-17099',NULL,NULL,'15685ac62c82738ab22e5938b96dac7e61c80c750aa68b7b43c1f51f88d3ac38','801a15d3bdab31d784e3b84175b39482e2cd58f42cdb666abb3ff8f2ad5c98d4',NULL,NULL,'student','approved','','Bachelor of Science in Information Technology','GIF89a\0\0�\0\0\0\0\0���!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-25 13:27:39','2025-11-25 13:55:01');
INSERT INTO `user_information` VALUES('5','$2y$10$6tAyQiAPfEMPMsTX9h8CP.QIRJMkmp35iKvF/NAGlrjEFt8GE3K7C','1f9aa10a89668f02dbc58514341ece89','Barky Anne','L.','Colas',NULL,'blcolas@usep.edu.ph','STU2025-89126',NULL,NULL,'b5534812946f386e6b960b430446f7f8ef7f9d26e608a4dc9aff49aa833d35bd','d197bbcd798642bcc65ecfd9f7e1b1ee27f8e780f8a1c2b184ac97ef348bfa77',NULL,NULL,'student','approved','','Bachelor of Science in Information Technology','GIF89a\0\0�\0\0\0\0\0���!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-25 13:28:24','2025-11-25 13:54:57');
INSERT INTO `user_information` VALUES('6','$2y$10$TxgdKDGTW5Bf8A6DAiDA.uMqoS/N/JzwOmtr5XJHTGHf1oqXebU26','b29801631fab07b3f0b6afbd45d8cd9e','Lee Martin','P.','Boja',NULL,'lpbja@usep.edu.ph','STU2025-74907',NULL,NULL,'26e110882e44dc7f5587ca70f02d717b68f90a4d1f8a89f9676f9cba6ed6e706','6c75efde6f70389b014b46acccb5db39e557ffc82d82c960ab718b1b65e6f5ca',NULL,NULL,'student','approved','','Bachelor of Science in Information Technology','GIF89a\0\0�\0\0\0\0\0���!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-25 13:29:16','2025-11-25 13:54:54');
INSERT INTO `user_information` VALUES('7','$2y$10$HjTvgD29smJni2kCUhW8w.rWNRXPbjTBCJx.baHS.CQYr.4HuAfFm','a55e649a0e7b986e3a4e764eeb938cc1','Michael Lorenz','P.','Nesperos',NULL,'mpnesperos@usep.edu.ph','STU2025-90562',NULL,NULL,'a8507807ee0634375f8f1f4b6aff7428d03db9fffc1c03bf908f69dbb4d675fd','01af51efc43e68e073fe2f83d7ed8b6bbceede4513bee97990b3612b6baf8de6',NULL,NULL,'student','approved','','Bachelor of Science in Information Technology','GIF89a\0\0�\0\0\0\0\0���!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-25 13:30:11','2025-11-25 13:54:48');
INSERT INTO `user_information` VALUES('8','$2y$10$/Mi6GS9lD65lFxaFfEgiKuViS.hSa7Xwro2aFzjlq99BzhqC/ET0G','fdcafbd0c3cc46d49f57fea42f950823','Lecil','G','Quibol',NULL,'lgquibol@usep.edu.ph','STU2025-69231',NULL,NULL,'e855c3e50831c104c33e9aaa4543d68f5dad50b8887eea1fb7187c56dc537a4e','1570f079a2cc60ea1c29e29dc722cedda3718cc3cadb14678c5c11d6b395b593',NULL,NULL,'student','approved','','Bachelor of Science in Information Technology','GIF89a\0\0�\0\0\0\0\0���!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-25 13:30:49','2025-11-25 13:54:44');
INSERT INTO `user_information` VALUES('9','$2y$10$iSq74YQgWmsHyRGyuaTiQu2dTSFba3QyPHs8mdtN5iC7V2U6Dl/3m','65c3c2c1f00c4a099875ac8e66839111','Alumar','P','Bangahon',NULL,'apbangahon@usep.edu.ph','STU2025-51829',NULL,NULL,'1d86977731823d783e7261639d36801d48148c0f173110184c6dba1ed424e445','0cba2932658f31c0f1fe1012f8e2647fefe9cd9ad4140fbadea43fe995b1d141',NULL,NULL,'student','approved','','Bachelor of Science in Information Technology','GIF89a\0\0�\0\0\0\0\0���!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-25 13:31:38','2025-11-25 13:54:40');
INSERT INTO `user_information` VALUES('10','$2y$10$vm.Zy1IGwaiqDyU2Vd9JO.kpnBL5UdqYDy7/pqDCPuunbbeqQ8JMu','4e69c2f2ee4ae07e1e50302b678c5d50','John Joseph','N','Dagondon',NULL,'jndagondon@usep.edu.ph','STU2025-96395',NULL,NULL,'cb92d9465b5d957138b2ecd5422c43947425b141871f2d589e9122848f71eec4','a97730a084c6ddba0324ba24fa7c3d800c569056928f34aba884bddfec0aea9b',NULL,NULL,'student','approved','','Bachelor of Science in Information Technology','GIF89a\0\0�\0\0\0\0\0���!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-25 13:32:36','2025-11-25 13:54:37');
INSERT INTO `user_information` VALUES('11','$2y$10$nVKi0vxE0uFW.iSdrfQdN.27nkf.Q09lleTvyJa65j0az.fQq9nza','bd52e07acf482d166ecd764c276019e2','Jaspher Jan','M.','Pagas',NULL,'jmpagas@usep.edu.ph','STU2025-36259',NULL,NULL,'9d07ed509da2a10d19f5345bf3fc99562d3b4cc2daca417e1ed4defa0d25dee5','caea4a7890f99f9451fe311940cc8917c33f2566af1f82e0c30c2e2d399e9de4',NULL,NULL,'student','approved','','Bachelor of Science in Information Technology','GIF89a\0\0�\0\0\0\0\0���!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-25 13:33:28','2025-11-25 13:54:33');
INSERT INTO `user_information` VALUES('12','$2y$10$yN8mR9fpoGcQhHj/6HCjbOJiO3GefSxMZry1AZYDl0PSSuBHo9XbS','e31585b5c0632fa0f62f7148b4c670f4','Jericho','E.','Saramosing',NULL,'jesaramosing@usep.edu.ph','STU2025-28182',NULL,NULL,'86e0ce5ea988ca8a0422e053d7f506276b0b01ee8e60d7014be234c91686f94c','a595295deb188ec16d0cd9581a61c51da0c1126e6dff5b6ff55cf958a31e4c17',NULL,NULL,'student','approved','','Bachelor of Science in Information Technology','GIF89a\0\0�\0\0\0\0\0���!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-25 13:34:14','2025-11-25 13:54:29');
INSERT INTO `user_information` VALUES('13','$2y$10$sa1idwNrOiqRuAlPzM5iCOzB9Zrm6l1zxhkcmFIkjrvPU58ZJM0nq','c939c8c84d43aed0f5e4a3d0770fc2e1','James Irnol','E.','Sasing',NULL,'jesasing@usep.edu.ph','STU2025-66429',NULL,NULL,'69094f93236369ebed421b891a5b36d250f34239bb2c25ef25244b724a8009fe','2501263b605d1bed8138555b8888a08b305de65c9302aa5590572aa085b03f4c',NULL,NULL,'student','approved','','Bachelor of Science in Information Technology','GIF89a\0\0�\0\0\0\0\0���!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-25 13:35:07','2025-11-25 13:54:26');
INSERT INTO `user_information` VALUES('14','$2y$10$vhpnIkMmXSejk1CZt6GcQeou292oxY9m3ZJp4ryRXtYgy3j3NT8i.','19b1d3b5af25a087d73a7d67b64a461b','Nal Semper','D.','Tiempo',NULL,'ndtiempo@usep.edu.ph','STU2025-63492',NULL,NULL,'cc81fe6b9300e2860464981ed66814cd1be399b5b01b99f37f3db9927a68310e','4ea1755574ad34b7d58c8c1f65c6f1512150e60edc6921e7d4b9ff988748b952',NULL,NULL,'student','approved','','Bachelor of Science in Information Technology','GIF89a\0\0�\0\0\0\0\0���!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-25 13:35:48','2025-11-25 13:54:21');
INSERT INTO `user_information` VALUES('15','$2y$10$xT1d5g8SbGW3qXgIJJHelOq7pSlCfUlmmQJhMb3oP46ZF9pJRigFa','c77affacc5a803e9aa4d1f9c98299791','Eric John','A','Batino',NULL,'eabatino@usep.edu.ph','STU2025-58024',NULL,NULL,'375ee988516353011e21ff1d9f43ce829715434a7b01d293ab1a972e1aa2b4a7','19240c8362bb32a08dc40beefcce00c7ec0649d77c1ab1ce15e718c9e9339754',NULL,NULL,'student','approved','','Bachelor of Science in Information Technology','GIF89a\0\0�\0\0\0\0\0���!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-25 13:36:35','2025-11-25 13:55:48');
INSERT INTO `user_information` VALUES('16','$2y$10$DpKgFSwAGE0nPv42lF.EDu0QONDunkvtvLtpXKvZvf.Qe4xQY/xNm','5b965c26efc1efd7d89a76868dce0206','Jill Viemark',NULL,'Lauronilla',NULL,'jlauronilla@usep.edu.ph','STU2025-68474',NULL,NULL,'c74ea08abd5189985af1ee5e0aa429c8ac6a3000012fd3a3933524ae27048055','4a5c8b18bfb99c2beb88d328aee6eb4724c219507cb940168de8ba7eb6c650b0',NULL,NULL,'student','approved','','Bachelor of Science in Information Technology','GIF89a\0\0�\0\0\0\0\0���!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-25 13:37:19','2025-11-25 13:55:44');
INSERT INTO `user_information` VALUES('17','$2y$10$s3uUfG0MGlpaV1aJ7JHeT.3Q5n33C1cvNI1VzIgCxwoxwNGeW3GaW','e561be71cb517b588d12c8359e9e13cd','Yla Jolina','F.','Ypon',NULL,'yfypon@usep.edu.ph','STU2025-87711',NULL,NULL,'0efc6d1fd7852856da36f98822bf2c02c0b45c0270ae4725c8269fd1bde22038','896ea17c6064342cb707bcb6d5622268621c38f507240b12b4a272b717b51abe',NULL,NULL,'student','approved','','Bachelor of Science in Information Technology','GIF89a\0\0�\0\0\0\0\0���!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-25 13:38:06','2025-11-25 13:55:41');
INSERT INTO `user_information` VALUES('20','$2y$10$M0Vhi03nkIomBlsNJOsK8uuPDexgUFElK0gGozdizaHrPAjCWZPuW','532e60f9a4bbae3eb7be481f492ac562','Hazel Ross','S.','Tomol',NULL,'hstomol@usep.edu.ph','STU2025-95002',NULL,NULL,'e5337a7b301363731b935cde299da2853b8379b08c7145fb4c9a407cbc4d9d33','114006eaee859962cd3b90d4e86240a0f6c9f53e7597d05ac14327382f016afb',NULL,NULL,'student','approved','','Bachelor of Science in Information Technology','GIF89a\0\0�\0\0\0\0\0���!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-25 13:40:46','2025-11-25 13:55:37');
INSERT INTO `user_information` VALUES('21','$2y$10$Sjto7KOFWQZS0NSxQjrhYuv9ZVp./HyQm1rvprv71Z33WEMrmiSt2','279ec8513b29cc43c0e180e97d7814a9','Michaella Myr','P.','Matratar',NULL,'mpmatratar@usep.edu.ph','STU2025-21352',NULL,NULL,'023b05c5250a071dfab16902954fce025b2e0672972cc182179ee06d4100650d','690263b28d22e4e4f351464b5f9350a9f7f215705273345ff3a44624591d1b9a',NULL,NULL,'student','approved','','Bachelor of Science in Information Technology','GIF89a\0\0�\0\0\0\0\0���!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-25 13:41:33','2025-11-25 13:55:34');
INSERT INTO `user_information` VALUES('22','$2y$10$QfV5u5kJOOen8d4XDkwSI.8BbaMsWnUmHDn2fEERmdHLYSdGOS10i','b3d2bd6239192771d1042879194ee36e','Neil','S.','Budanio',NULL,'nsbudanio@usep.edu.ph','STU2025-18549',NULL,NULL,'ade44df4c2d5724d18a49cf706b3a4293b179b2011d38734fb056f1a7f24413d','41e4b131435ba3b58ac0d5ffed897795868fd80d2d843a13c3cc1e3a6b8271d9',NULL,NULL,'student','approved','','Bachelor of Science in Information Technology','GIF89a\0\0�\0\0\0\0\0���!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-25 13:42:35','2025-11-25 13:55:30');
INSERT INTO `user_information` VALUES('23','$2y$10$X0vxqmAOCSXcu8hbrTTmcOBFpM1CmLyujXDoR7iS1Vq3xdrRmR0Ji','1b3835239266a42bf0c0c32a9c7073e7','Vinch Kyle','V','Delgado',NULL,'vvdelgado@usep.edu.ph','STU2025-75232',NULL,NULL,'107f9386789a7ebd058b933048b58922946ea6261b47b20c8eaa26b8b6480656','7fb6690496b83d35a8541812c18b4666109f41cdca1c8976a2ebf7a6ef945dc8',NULL,NULL,'student','approved','','Bachelor of Science in Information Technology','GIF89a\0\0�\0\0\0\0\0���!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-25 13:43:23','2025-11-25 13:55:27');
INSERT INTO `user_information` VALUES('24','$2y$10$hSGxUlZJr4ua3vb3r9idu.nGKU8r2naGm7a0cm13pJFDgOHg9JC5W','d53552d478023628cc8eae447362653b','Arnold','E.','Razonable','Jr.','aerazonable@usep.edu.ph','STU2025-72561',NULL,NULL,'250631f457ae548fefe891b68c7ad7dd7a6b117bddde4252153b41eaf416f05d','f1f5ef4a61c8860344b90244cebfdb1f6d676ff576d96ee42b9e738c696de4cd',NULL,NULL,'student','approved','','Bachelor of Science in Information Technology','GIF89a\0\0�\0\0\0\0\0���!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-25 13:44:10','2025-11-25 13:55:23');
INSERT INTO `user_information` VALUES('25','$2y$10$CN9RMqj0RNeCc4GiHLvMDOChT76PK2b9.sam736.swBCTgIwTMVFO','5651f7728b62191fe3a04784cbed1ff9','Kem','B.','Albert',NULL,'kbalbert@usep.edu.ph','STU2025-51323',NULL,NULL,'f23965c0f4959d5914b6919260d69330ab04f7c1519e22fcc0d30cb5fb0d23a4','c7eab6d78a55ec8f90caf7c5b27dd7fe5e97dd0b7c83306465b18ec91fddaa12',NULL,NULL,'student','approved','','Bachelor of Science in Information Technology','GIF89a\0\0�\0\0\0\0\0���!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-25 13:45:03','2025-11-25 13:54:15');
INSERT INTO `user_information` VALUES('26','$2y$10$LlX8gPRtgzKwOpPz4T2.r.zDbMXwX/Nmd1N/tP3lNKVYVZ.5be6Na','83671adc623f0c0f395b3320aa149530','Earvin Chance','A','Bioco',NULL,'eabioco@usep.edu.ph','STU2025-60833',NULL,NULL,'84492f29cf9cc23e59cae058a93d4309ec18d17636a48a9352e54c4e71f68d3c','dfdb05d5bff457f79a584c6ecac83da249da5f5a3ab6286833c4870ddc0461ca',NULL,NULL,'student','approved','','Bachelor of Science in Information Technology','GIF89a\0\0�\0\0\0\0\0���!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-25 13:45:45','2025-11-25 13:54:11');
INSERT INTO `user_information` VALUES('27','$2y$10$W/M97erCGD5VYmqEpS/SFeSL7Y2Wlv9.pTx2GwuTLk4rTupZNHNWy','40e4f6980eeeb999a9742e8f0ac41f2d','Roque','A.','Longgakit','Jr.','ralonggakit@usep.edu.ph','STU2025-38119',NULL,NULL,'13cf1cfd4d1336414d608e793df6d01b77e21b8cf67e1e04a190fc0ed3c56dbd','7d520ebbc83a8860eef0db039f3a47a1d8e6ec5525cc233d50879e0d0dd4ec7c',NULL,NULL,'student','approved','','Bachelor of Science in Information Technology','GIF89a\0\0�\0\0\0\0\0���!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-25 13:47:01','2025-11-25 13:54:08');
INSERT INTO `user_information` VALUES('28','$2y$10$.pgGuRIRsLlUTzqZ7.xurO2pGNAK5/JUyx4WnaVvZLFh8.qvtdwby','a876028a2ec08c82a2540c834b92ec1e','Editha','L.','Hebron',NULL,'elhebron@usep.edu.ph','FAC2025-69447',NULL,NULL,'92815b025e3930acc8ee44e3f684e4e8f4dc1bbb05cfd15f7eac38a1a5786762','d4c793a56797773dd93173a6093341ce71c58c8e1dc4dd25073927cc00120b65',NULL,NULL,'faculty','approved','CTET','','GIF89a\0\0�\0\0\0\0\0���!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-25 13:47:53','2025-11-25 13:54:03');
INSERT INTO `user_information` VALUES('29','$2y$10$fBFh0qNmanZSbM2u5KDmyuHbSH6HS3JSIuJLwtubfcNCyQmLR5.oO','d60111e60a3d504b621808943f4ab122','Mishill','D.','Cempron',NULL,'mdcempron@usep.edu.ph','FAC2025-57084',NULL,NULL,'5bf53e95f1a21aad722094f46d807d6c1137a20e4ccca15d7241f84e0872a4c7','047ed21e0e37e0e8fd3e49359210167e4396ec61ccccbf367a833f184fc8f962',NULL,NULL,'faculty','approved','CTET','','GIF89a\0\0�\0\0\0\0\0���!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-25 13:48:38','2025-11-25 13:53:59');
INSERT INTO `user_information` VALUES('30','$2y$10$qDxopU2TRZd1aSSEQdXbweidT4qx42ymrkYYDJSFIFzdyrlk6aqLy','efeab595666d8bbf212574e369b077f4','Archie','A.','Cenas',NULL,'aacenas@usep.edu.ph','FAC2025-46974',NULL,NULL,'64a14daadab8c83cc65b2580ac2229f39e1d03ee7ee80dece03a69f5495d8a8a','ddb9c55745176b73220800f5aa804372e0da3c4d4cccf48cd46f165a374caedc',NULL,NULL,'faculty','approved','CTET','','GIF89a\0\0�\0\0\0\0\0���!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-25 13:49:47','2025-11-25 13:53:56');
INSERT INTO `user_information` VALUES('31','$2y$10$TL0FL9uOvtrylIOXXurzVeRAvEEmdpFi56Eiuq40rfMGoY5vP/MqO','d598a52af0fe0d6632b5fe649b160ba7','Luchi','A.','Dela Cruz',NULL,'ladelacruz@usep.edu.ph','FAC2025-81009',NULL,NULL,'fd96daf4ce4321da4038d437daadf1f557f1e506153a318727b0a08d9e83b28b','e9301ad573f73bb30ef37393d95fbc7adf97a170fc313f382d6a01f04ac5ec24',NULL,NULL,'faculty','approved','CTET','','GIF89a\0\0�\0\0\0\0\0���!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-25 13:50:33','2025-11-25 13:53:44');
INSERT INTO `user_information` VALUES('32','$2y$10$rI9Ot5miuKcNZAFtQKvk..fCVQOQQoHd92HDVyAECfxZDZCWGy10G','d48dfcff39c02e5c1ccb4cdcf462f1d5','Rey','M.','De Leon',NULL,'rmdeleon@usep.edu.ph','FAC2025-02046',NULL,NULL,'a1b8f17b4fc9a811edff98b47efaa59de98fc8ff91470c63b1a22ddd38f95c2b','58a22c512aa526cb96dda30cf3e616c456500d1ba36741f9640170ca9032ba2e',NULL,NULL,'faculty','approved','CTET','','GIF89a\0\0�\0\0\0\0\0���!�\0\0\0\0,\0\0\0\0\0\0\0D\0;','2025-11-25 13:51:10','2025-11-25 14:08:56');

--
-- Table structure for table `vw_active_announcements`
--
DROP TABLE IF EXISTS `vw_active_announcements`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_active_announcements` AS select `a`.`id` AS `id`,`a`.`title` AS `title`,`a`.`content` AS `content`,`a`.`type` AS `type`,`a`.`start_date` AS `start_date`,`a`.`end_date` AS `end_date`,`a`.`is_pinned` AS `is_pinned`,`a`.`status` AS `status`,`a`.`created_by` AS `created_by`,`a`.`created_at` AS `created_at`,`a`.`updated_at` AS `updated_at`,concat(`ui`.`First_Name`,' ',`ui`.`Last_Name`) AS `created_by_name`,`ui`.`Email` AS `created_by_email` from (`announcements` `a` left join `user_information` `ui` on((`a`.`created_by` = `ui`.`ID`))) where ((`a`.`status` = 'published') and (`a`.`start_date` <= now()) and ((`a`.`end_date` is null) or (`a`.`end_date` >= now()))) order by `a`.`is_pinned` desc,`a`.`created_at` desc;

--
-- Dumping data for table `vw_active_announcements`
--
INSERT INTO `vw_active_announcements` VALUES('4','Mandatory System Account Verification','All registered students must verify their Compendium Thesis System accounts no later than December 5, 2025. Unverified accounts may experience restricted access to key features such as uploading and document retrieval. Please check your email for the verification link.','important','2025-11-25 13:59:00','2025-12-05 14:00:00','0','published','1','2025-11-25 14:00:17','0000-00-00 00:00:00','Super Admin','admin@usep.edu.ph');
INSERT INTO `vw_active_announcements` VALUES('3','Orientation on the Compendium Thesis System','The BSIT Department will conduct a brief orientation on how to use the Compendium Thesis System on November 30, 2025, at 2:00 PM in the ICT Laboratory. The session will cover account access, uploading guidelines, and system features. All thesis groups are encouraged to attend.','event','2025-11-25 13:59:00','2025-11-30 13:59:00','0','published','1','2025-11-25 13:59:34','0000-00-00 00:00:00','Super Admin','admin@usep.edu.ph');
INSERT INTO `vw_active_announcements` VALUES('2','Final Submission Deadline for Thesis Documents','All students are reminded that the final deadline for uploading thesis manuscripts to the Compendium Thesis System is December 15, 2025. Late submissions will not be accommodated. Please ensure all files are complete, properly formatted, and verified before uploading.','deadline','2025-11-25 13:58:00','2025-12-15 13:58:00','0','published','1','2025-11-25 13:59:01','0000-00-00 00:00:00','Super Admin','admin@usep.edu.ph');
INSERT INTO `vw_active_announcements` VALUES('1','System Update: Compendium Thesis Platform Enhancements','We are pleased to inform all BSIT students that the Compendium Thesis System has been updated with improved search functionality and faster loading time. These enhancements aim to provide a smoother experience when accessing thesis documents. For any system concerns, please contact the development team.','information','2025-11-25 13:57:00','2025-12-02 13:58:00','0','published','1','2025-11-25 13:58:12','0000-00-00 00:00:00','Super Admin','admin@usep.edu.ph');

--
-- Table structure for table `vw_system_statistics`
--
DROP TABLE IF EXISTS `vw_system_statistics`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_system_statistics` AS select (select count(0) from `user_information`) AS `total_users`,(select count(0) from `user_information` where (`user_information`.`Acc_Status` = 'approved')) AS `approved_users`,(select count(0) from `user_information` where (`user_information`.`Acc_Status` = 'pending')) AS `pending_users`,(select count(0) from `thesis`) AS `total_theses`,(select count(0) from `announcements` where (`announcements`.`status` = 'published')) AS `active_announcements`,(select count(0) from `thesis_reviews`) AS `total_reviews`,(select count(0) from `login_attempts` where ((`login_attempts`.`success` = 1) and (cast(`login_attempts`.`attempt_time` as date) = curdate()))) AS `today_logins`,(select count(0) from `notifications` where (`notifications`.`is_read` = 0)) AS `unread_notifications`;

--
-- Dumping data for table `vw_system_statistics`
--
INSERT INTO `vw_system_statistics` VALUES('30','30','0','0','4','0','0','32');

--
-- Table structure for table `vw_thesis_details`
--
DROP TABLE IF EXISTS `vw_thesis_details`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_thesis_details` AS select `t`.`ID` AS `ID`,`t`.`Title` AS `Title`,`t`.`Author` AS `Author`,`t`.`Adviser` AS `Adviser`,`t`.`Thesis_Department` AS `Thesis_Department`,`t`.`Thesis_Course` AS `Thesis_Course`,`t`.`HardBound_Available` AS `HardBound_Available`,`t`.`uploaded_at` AS `uploaded_at`,`ui`.`First_Name` AS `uploader_first_name`,`ui`.`Last_Name` AS `uploader_last_name`,`ui`.`Email` AS `uploader_email`,coalesce(avg(`tr`.`rating`),0) AS `average_rating`,count(`tr`.`ID`) AS `review_count` from ((`thesis` `t` left join `user_information` `ui` on((`t`.`User_ID` = `ui`.`ID`))) left join `thesis_reviews` `tr` on((`t`.`ID` = `tr`.`thesis_id`))) group by `t`.`ID`;

--
-- Dumping data for table `vw_thesis_details`
--

--
-- Table structure for table `vw_user_summary`
--
DROP TABLE IF EXISTS `vw_user_summary`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_user_summary` AS select `ui`.`ID` AS `ID`,`ui`.`First_Name` AS `First_Name`,`ui`.`Last_Name` AS `Last_Name`,`ui`.`Email` AS `Email`,`ui`.`User_Role` AS `User_Role`,`ui`.`Acc_Status` AS `Acc_Status`,`ui`.`Department` AS `Department`,`ui`.`Course` AS `Course`,`ui`.`created_at` AS `created_at`,count(distinct `t`.`ID`) AS `thesis_count`,count(distinct `tr`.`ID`) AS `reviews_count`,(select count(0) from `thesis_reviews` `tr2` where (`tr2`.`reviewer_id` = `ui`.`ID`)) AS `reviews_given` from ((`user_information` `ui` left join `thesis` `t` on((`ui`.`ID` = `t`.`User_ID`))) left join `thesis_reviews` `tr` on((`ui`.`ID` = `tr`.`reviewer_id`))) group by `ui`.`ID`;

--
-- Dumping data for table `vw_user_summary`
--
INSERT INTO `vw_user_summary` VALUES('1','Super','Admin','admin@usep.edu.ph','superAdmin','approved','Administration','Administration','2025-11-25 13:16:16','0','0','0');
INSERT INTO `vw_user_summary` VALUES('2','Harold Carl','Carcallas','hycarcallas@usep.edu.ph','student','approved','','Bachelor of Science in Information Technology','2025-11-25 13:18:56','0','0','0');
INSERT INTO `vw_user_summary` VALUES('3','Regine Joy Dorothy','Saliot','rlsaliot@usep.edu.ph','student','approved','','Bachelor of Science in Information Technology','2025-11-25 13:26:19','0','0','0');
INSERT INTO `vw_user_summary` VALUES('4','Shyrell Mae','Begonia','smbegonia@usep.edu.ph','student','approved','','Bachelor of Science in Information Technology','2025-11-25 13:27:39','0','0','0');
INSERT INTO `vw_user_summary` VALUES('5','Barky Anne','Colas','blcolas@usep.edu.ph','student','approved','','Bachelor of Science in Information Technology','2025-11-25 13:28:24','0','0','0');
INSERT INTO `vw_user_summary` VALUES('6','Lee Martin','Boja','lpbja@usep.edu.ph','student','approved','','Bachelor of Science in Information Technology','2025-11-25 13:29:16','0','0','0');
INSERT INTO `vw_user_summary` VALUES('7','Michael Lorenz','Nesperos','mpnesperos@usep.edu.ph','student','approved','','Bachelor of Science in Information Technology','2025-11-25 13:30:11','0','0','0');
INSERT INTO `vw_user_summary` VALUES('8','Lecil','Quibol','lgquibol@usep.edu.ph','student','approved','','Bachelor of Science in Information Technology','2025-11-25 13:30:49','0','0','0');
INSERT INTO `vw_user_summary` VALUES('9','Alumar','Bangahon','apbangahon@usep.edu.ph','student','approved','','Bachelor of Science in Information Technology','2025-11-25 13:31:38','0','0','0');
INSERT INTO `vw_user_summary` VALUES('10','John Joseph','Dagondon','jndagondon@usep.edu.ph','student','approved','','Bachelor of Science in Information Technology','2025-11-25 13:32:36','0','0','0');
INSERT INTO `vw_user_summary` VALUES('11','Jaspher Jan','Pagas','jmpagas@usep.edu.ph','student','approved','','Bachelor of Science in Information Technology','2025-11-25 13:33:28','0','0','0');
INSERT INTO `vw_user_summary` VALUES('12','Jericho','Saramosing','jesaramosing@usep.edu.ph','student','approved','','Bachelor of Science in Information Technology','2025-11-25 13:34:14','0','0','0');
INSERT INTO `vw_user_summary` VALUES('13','James Irnol','Sasing','jesasing@usep.edu.ph','student','approved','','Bachelor of Science in Information Technology','2025-11-25 13:35:07','0','0','0');
INSERT INTO `vw_user_summary` VALUES('14','Nal Semper','Tiempo','ndtiempo@usep.edu.ph','student','approved','','Bachelor of Science in Information Technology','2025-11-25 13:35:48','0','0','0');
INSERT INTO `vw_user_summary` VALUES('15','Eric John','Batino','eabatino@usep.edu.ph','student','approved','','Bachelor of Science in Information Technology','2025-11-25 13:36:35','0','0','0');
INSERT INTO `vw_user_summary` VALUES('16','Jill Viemark','Lauronilla','jlauronilla@usep.edu.ph','student','approved','','Bachelor of Science in Information Technology','2025-11-25 13:37:19','0','0','0');
INSERT INTO `vw_user_summary` VALUES('17','Yla Jolina','Ypon','yfypon@usep.edu.ph','student','approved','','Bachelor of Science in Information Technology','2025-11-25 13:38:06','0','0','0');
INSERT INTO `vw_user_summary` VALUES('20','Hazel Ross','Tomol','hstomol@usep.edu.ph','student','approved','','Bachelor of Science in Information Technology','2025-11-25 13:40:46','0','0','0');
INSERT INTO `vw_user_summary` VALUES('21','Michaella Myr','Matratar','mpmatratar@usep.edu.ph','student','approved','','Bachelor of Science in Information Technology','2025-11-25 13:41:33','0','0','0');
INSERT INTO `vw_user_summary` VALUES('22','Neil','Budanio','nsbudanio@usep.edu.ph','student','approved','','Bachelor of Science in Information Technology','2025-11-25 13:42:35','0','0','0');
INSERT INTO `vw_user_summary` VALUES('23','Vinch Kyle','Delgado','vvdelgado@usep.edu.ph','student','approved','','Bachelor of Science in Information Technology','2025-11-25 13:43:23','0','0','0');
INSERT INTO `vw_user_summary` VALUES('24','Arnold','Razonable','aerazonable@usep.edu.ph','student','approved','','Bachelor of Science in Information Technology','2025-11-25 13:44:10','0','0','0');
INSERT INTO `vw_user_summary` VALUES('25','Kem','Albert','kbalbert@usep.edu.ph','student','approved','','Bachelor of Science in Information Technology','2025-11-25 13:45:03','0','0','0');
INSERT INTO `vw_user_summary` VALUES('26','Earvin Chance','Bioco','eabioco@usep.edu.ph','student','approved','','Bachelor of Science in Information Technology','2025-11-25 13:45:45','0','0','0');
INSERT INTO `vw_user_summary` VALUES('27','Roque','Longgakit','ralonggakit@usep.edu.ph','student','approved','','Bachelor of Science in Information Technology','2025-11-25 13:47:01','0','0','0');
INSERT INTO `vw_user_summary` VALUES('28','Editha','Hebron','elhebron@usep.edu.ph','faculty','approved','CTET','','2025-11-25 13:47:53','0','0','0');
INSERT INTO `vw_user_summary` VALUES('29','Mishill','Cempron','mdcempron@usep.edu.ph','faculty','approved','CTET','','2025-11-25 13:48:38','0','0','0');
INSERT INTO `vw_user_summary` VALUES('30','Archie','Cenas','aacenas@usep.edu.ph','faculty','approved','CTET','','2025-11-25 13:49:47','0','0','0');
INSERT INTO `vw_user_summary` VALUES('31','Luchi','Dela Cruz','ladelacruz@usep.edu.ph','faculty','approved','CTET','','2025-11-25 13:50:33','0','0','0');
INSERT INTO `vw_user_summary` VALUES('32','Rey','De Leon','rmdeleon@usep.edu.ph','faculty','approved','CTET','','2025-11-25 13:51:10','0','0','0');

SET FOREIGN_KEY_CHECKS=1;
